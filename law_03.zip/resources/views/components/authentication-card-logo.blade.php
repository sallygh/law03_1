<a href="/">
    <img src="{{ asset('images/A.png') }}" alt="Your Logo" style="height: 40px;">
</a>