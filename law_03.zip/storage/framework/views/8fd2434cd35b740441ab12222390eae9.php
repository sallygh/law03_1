

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h1>تعديل القضية</h1>
    <form action="<?php echo e(route('lawsuits.update', $lawsuit->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <?php echo $__env->make('lawsuits.form', ['lawsuit' => $lawsuit, 'lawsuitTypes' => $lawsuitTypes, 'clients' => $clients], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <button type="submit" class="btn btn-primary mt-3">تحديث</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\law_03\resources\views/lawsuits/edit.blade.php ENDPATH**/ ?>