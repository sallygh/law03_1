

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>إضافة موكل جديد</h1>
    <form action="<?php echo e(route('clients.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="full_name">الاسم الثلاثي</label>
            <input type="text" name="full_name" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="phone">رقم الهاتف</label>
            <input type="text" name="phone" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="address">العنوان</label>
            <input type="text" name="address" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="notes">ملاحظات</label>
            <textarea name="notes" class="form-control"></textarea>
        </div>
        <button type="submit" class="btn btn-primary">حفظ</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\law_03\resources\views/clients/create.blade.php ENDPATH**/ ?>