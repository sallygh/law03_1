

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h1 class="mb-4 text-center">تفاصيل القضية</h1>
    <div class="card">
        <div class="card-body">
            <table class="table table-bordered">
                <tbody>
                    <tr>
                        <th class="align-middle">رقم القضية</th>
                        <td class="align-middle"><?php echo e($lawsuit->id); ?></td>
                    </tr>
                    <tr>
                        <th class="align-middle">تصنيف الدعوى</th>
                        <td class="align-middle"><?php echo e($lawsuit->lawsuit_type); ?></td>
                    </tr>
                    <tr>
                        <th class="align-middle">موضوع الدعوى</th>
                        <td class="align-middle"><?php echo e($lawsuit->lawsuit_subject); ?></td>
                    </tr>
                    <tr>
                        <th class="align-middle">المحكمة</th>
                        <td class="align-middle"><?php echo e($lawsuit->court); ?></td>
                    </tr>
                    <tr>
                        <th class="align-middle">رقم المحكمة</th>
                        <td class="align-middle"><?php echo e($lawsuit->court_number); ?></td>
                    </tr>
                    <tr>
                        <th class="align-middle">اسم المدعي</th>
                        <td class="align-middle"><?php echo e($lawsuit->plaintiff->full_name); ?></td>
                    </tr>
                    <tr>
                        <th class="align-middle">اسم المدعى عليه</th>
                        <td class="align-middle"><?php echo e($lawsuit->defendant->full_name); ?></td>

                    <tr>
                        <th class="align-middle">حالة القضية</th>
                        <td class="align-middle"><?php echo e($lawsuit->lawsuit_status); ?></td>
                    </tr>
                    <tr>
                        <th class="align-middle"> رقم الاساس</th>
                        <td class="align-middle"><?php echo e($lawsuit->base_number); ?></td>
                    </tr>
                    <tr>
                        <th class="align-middle">رقم القرار </th>
                        <td class="align-middle"><?php echo e($lawsuit->decision_number); ?></td>
                    </tr>
                    <tr>
                        <th class="align-middle">المبلغ المتفق عليه</th>
                        <td class="align-middle"><?php echo e($lawsuit->agreed_amount); ?></td>
                    </tr>
                    <tr>
                        <th class="align-middle">المبلغ المتبقي</th>
                        <td class="align-middle"><?php echo e($lawsuit->remaining_amount); ?></td>
                    </tr>
                    <tr>
                        <th class="align-middle">المبلغ المدفوع</th>
                        <td class="align-middle"><?php echo e($lawsuit->paid_amount); ?></td>
                    </tr>
                    <tr>
                        <th>ملاحظات</th>
                        <td class="align-middle"><?php echo e($lawsuit->notes); ?></td>
                    </tr>
                    <tr>
                        <th class="align-middle">مرفقات</th>
                        <td class="align-middle">
                            <ul class="list-group list-group-flush text-center">
                                <?php if($lawsuit->attachments): ?>
                                <?php $__currentLoopData = json_decode($lawsuit->attachments, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="list-group-item"><a href="<?php echo e(asset('storage/' . $attachment)); ?>" target="_blank">عرض المرفق</a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <li class="list-group-item">لا توجد مرفقات</li>
                                <?php endif; ?>
                            </ul>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    <a href="<?php echo e(route('lawsuits.index')); ?>" class="btn btn-primary mt-3">العودة إلى قائمة القضايا</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\law_03\resources\views/lawsuits/show.blade.php ENDPATH**/ ?>