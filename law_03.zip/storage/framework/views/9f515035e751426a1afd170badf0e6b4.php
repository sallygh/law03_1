<a href="/">
    <img src="<?php echo e(asset('images/A.png')); ?>" alt="Your Logo" style="height: 40px;">
</a><?php /**PATH C:\laragon\www\law_03\resources\views/components/authentication-card-logo.blade.php ENDPATH**/ ?>