

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h1 class="text-2xl font-bold mb-4 text-center">إضافة قضية جديدة</h1>
    <form action="<?php echo e(route('lawsuits.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo $__env->make('lawsuits.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <button type="submit" class="btn btn-primary mt-3">حفظ</button>
    </form>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\law_03\resources\views/lawsuits/create.blade.php ENDPATH**/ ?>