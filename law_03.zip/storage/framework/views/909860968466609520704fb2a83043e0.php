

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>قائمة الموكلين</h1>
    <a href="<?php echo e(route('clients.create')); ?>" class="btn btn-primary">إضافة موكل جديد</a>
    <table class="table">
        <thead>
            <tr>
                <th>رقم</th>
                <th>الاسم الثلاثي</th>
                <th>رقم الهاتف</th>
                <th>العنوان</th>
                <th>إجراءات</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($client->id); ?></td>
                <td><?php echo e($client->full_name); ?></td>
                <td><?php echo e($client->phone); ?></td>
                <td><?php echo e($client->address); ?></td>
                <td>
                    <a href="<?php echo e(route('clients.show', $client->id)); ?>" class="btn btn-info">عرض</a>
                    <a href="<?php echo e(route('clients.edit', $client->id)); ?>" class="btn btn-warning">تعديل</a>
                    <form action="<?php echo e(route('clients.destroy', $client->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">حذف</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\law_03\resources\views/clients/index.blade.php ENDPATH**/ ?>