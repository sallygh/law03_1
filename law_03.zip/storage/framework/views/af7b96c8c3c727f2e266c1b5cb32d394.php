<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">

        </h2>
        <style>
            .cta-button {
                display: inline-block;
                margin: 20px auto;
                padding: 10px 20px;
                background: #fff;
                /* اللون الأساسي للزر */
                color: #DAA520;
                /* لون النص */
                border: 2px solid #DAA520;
                /* حدود الزر */
                border-radius: 5px;
                text-decoration: none;
                transition: background 0.3s, color 0.3s, transform 0.3s;
                /* انتقالات لتحسين التأثيرات */
            }

            .cta-button:hover {
                background: #DAA520;
                /* اللون عند التحويم */
                color: #fff;
                /* لون النص عند التحويم */
                transform: scale(1.05);
                /* تأثير التكبير عند التحويم */
            }
        </style>

        <div class="py-12">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

                <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                    <a href="<?php echo e(route('lawsuits.index')); ?>" class="cta-button text-center hover:bg-yellow-500 hover:text-white transform hover:scale-105 transition-all duration-300" title="إدارة القضايا">
                        إدارة القضايا
                    </a>
                    <a href="<?php echo e(route('clients.index')); ?>" class="cta-button text-center hover:bg-yellow-500 hover:text-white transform hover:scale-105 transition-all duration-300" title="إدارة الموكلين">
                        إدارة الموكلين
                    </a>
                    <a href="#" onclick="alert('قيد التطوير حاليًا'); return false;" class="cta-button text-center hover:bg-yellow-500 hover:text-white transform hover:scale-105 transition-all duration-300" title="إدارة المهام">
                        إدارة المهام
                    </a>
                    <a href="#" onclick="alert('قيد التطوير حاليًا'); return false;" class="cta-button text-center hover:bg-yellow-500 hover:text-white transform hover:scale-105 transition-all duration-300" title="إدارة المستندات">
                        إدارة المستندات
                    </a>
                    <a href="#" onclick="alert('قيد التطوير حاليًا'); return false;" class="cta-button text-center hover:bg-yellow-500 hover:text-white transform hover:scale-105 transition-all duration-300" title="إدارة المالية">
                        إدارة المالية
                    </a>
                    <a href="#" onclick="alert('قيد التطوير حاليًا'); return false;" class="cta-button text-center hover:bg-yellow-500 hover:text-white transform hover:scale-105 transition-all duration-300" title="بحث">
                        بحث
                    </a>
                </div>

            </div>
        </div>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\law_03\resources\views/dashboard.blade.php ENDPATH**/ ?>